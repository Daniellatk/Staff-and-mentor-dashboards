# MentorMatch Mentor Dashboard

Open `index.html` in any browser. No build step or install needed.

## What's inside
- Orientation (first page): the staff-written orientation, showing sections for everyone and for mentors
- Schedule: lessons, match date, program end, and optional check-ins the mentor can add or remove
- Lessons: the four 30-minute lessons with each goal, what the student brings, and suggested questions

## Sample data
The mentor, mentee, lessons and orientation text are sample data, defined in the
`SAMPLE DATA` block at the top of the `<script>` in `index.html`.
Replace that block with calls to your AWS backend (API Gateway + Lambda).
Check-ins added on the page only last until it is reloaded.
