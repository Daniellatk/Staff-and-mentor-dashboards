# MentorMatch Staff Dashboard

Open `index.html` in any browser. No build step or install needed.

## What's inside
- Orientation: edit the orientation page shown to mentees, mentors and staff
- Match review: approve or deny matches (with a reason), then send match emails
- Participants: roster with matches, attendance and homework pass/fail
- Lessons & attendance: who attended each lesson (weekly or every 2 weeks)
- Homework: prework/postwork completion grid with pass/fail
- Analytics: sign-ups over time, attendance per lesson, student funnel

## Sample data
All people, scores and dates are sample data, defined in the
`SAMPLE DATA` block at the top of the `<script>` in `index.html`.
Replace that block with calls to your AWS backend (API Gateway + Lambda).
Approvals, denials and orientation edits only last until the page is reloaded.

The "Sample date" switch in the header is for demos; in production, use today's date.
